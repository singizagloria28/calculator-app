import 'package:flutter/material.dart';

class  CalculatorScreen extends StatelessWidget {
  const CalculatorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
      ),
      body: CalculatorBody(),
    );
  }
}

class CalculatorBody extends StatefulWidget {
  @override
  _CalculatorBodyState createState() => _CalculatorBodyState();
}

class _CalculatorBodyState extends State<CalculatorBody> {
  String _output = "0";
  String _input = "";
  String _operator = "";
  double _num1 = 0;
  double _num2 = 0;
  bool _isOperatorClicked = false;
  bool _isEqualClicked = false;

  void _buttonPressed(String value) {
    if (value == "C") {
      _clear();
    } else if (value == "=") {
      _calculate();
    } else if (_isNumeric(value) || value == ".") {
      _handleNumeric(value);
    } else {
      _handleOperator(value);
    }
  }

  void _clear() {
    setState(() {
      _output = "0";
      _input = "";
      _operator = "";
      _num1 = 0;
      _num2 = 0;
      _isOperatorClicked = false;
      _isEqualClicked = false;
    });
  }

  void _calculate() {
    if (_operator.isNotEmpty && _input.isNotEmpty) {
      _num2 = double.parse(_input);
      double result = 0;
      switch (_operator) {
        case "+":
          result = _num1 + _num2;
          break;
        case "-":
          result = _num1 - _num2;
          break;
        case "*":
          result = _num1 * _num2;
          break;
        case "/":
          result = _num2 != 0 ? _num1 / _num2 : 0;
          break;
      }
      setState(() {
        _output = result.toString();
        _input = "";
        _num1 = result;
        _operator = "";
        _isOperatorClicked = false;
        _isEqualClicked = true;
      });
    }
  }

  void _handleNumeric(String value) {
    setState(() {
      if (_isEqualClicked) {
        _output = value;
        _isEqualClicked = false;
      } else {
        _output += value;
      }
      _input += value;
    });
  }

  void _handleOperator(String value) {
    if (_input.isNotEmpty) {
      _num1 = double.parse(_input);
      _input = "";
      setState(() {
        _operator = value;
        _output += " " + value + " ";
        _isOperatorClicked = true;
      });
    }
  }

  bool _isNumeric(String value) {
    return double.tryParse(value) != null;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Expanded(
          child: Container(
            alignment: Alignment.centerRight,
            padding: EdgeInsets.symmetric(vertical: 24, horizontal: 12),
            child: Text(
              _output,
              style: TextStyle(fontSize: 48, fontWeight: FontWeight.bold),
            ),
          ),
        ),
        Expanded(
          flex: 3,
          child: Column(
            children: [
              buildButtonRow(["7", "8", "9", "/"]),
              buildButtonRow(["4", "5", "6", "*"]),
              buildButtonRow(["1", "2", "3", "-"]),
              buildButtonRow(["C", "0", "=", "+"]),
            ],
          ),
        ),
      ],
    );
  }

  Widget buildButtonRow(List<String> values) {
    return Expanded(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: values.map((value) {
          return Expanded(
            child: ElevatedButton(
              onPressed: () => _buttonPressed(value),
              child: Text(
                value,
                style: TextStyle(fontSize: 24),
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}

